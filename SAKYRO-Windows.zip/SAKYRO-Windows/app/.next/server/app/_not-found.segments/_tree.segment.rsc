:HL["/_next/static/chunks/2458knb5j4q1y.css","style"]
2:[["children",{"s":"__PAGE__","h":160}]]
1:[["children",{"s":"/_not-found","h":96,"c":"$Q2"}]]
0:{"b":"ucxdvVQcbUtvLw95SD_B9","t":{"t":{"s":"","h":80,"c":"$Q1"}}}
